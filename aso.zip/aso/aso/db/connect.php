<?php
$db=mysqli_connect('localhost', 'root', '', 'aso_kitchen');
if (!$db){
	die("connection failed".mysqli_connect_error());
}
$db->set_charset('utf8');

?>