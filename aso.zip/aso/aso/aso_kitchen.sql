-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 19, 2021 at 08:08 PM
-- Server version: 10.4.16-MariaDB
-- PHP Version: 7.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aso_kitchen`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `p_id` int(11) NOT NULL,
  `p_code` text COLLATE utf8_persian_ci NOT NULL,
  `P_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci NOT NULL,
  `p_model` varchar(15) COLLATE utf8_persian_ci DEFAULT NULL,
  `p_category` text CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci DEFAULT NULL,
  `p_stock` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='product table';

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `p_code`, `P_name`, `p_model`, `p_category`, `p_stock`) VALUES
(1, 'm2411', 'DAEWOO 40GR51 Microwave', NULL, 'microwave', 12),
(6, 'b8811', 'KOIOS', NULL, 'blender', 25);

-- --------------------------------------------------------

--
-- Table structure for table `reqorder`
--

CREATE TABLE `reqorder` (
  `o_id` int(11) NOT NULL,
  `p_code` int(11) NOT NULL,
  `o_username` text NOT NULL,
  `o_email` text NOT NULL,
  `o_pcat` text NOT NULL,
  `Address` text CHARACTER SET utf8 COLLATE utf8_persian_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `user_username` text COLLATE utf8_persian_ci NOT NULL,
  `user_fullname` text COLLATE utf8_persian_ci NOT NULL,
  `user_Email` text COLLATE utf8_persian_ci NOT NULL,
  `user_password` text COLLATE utf8_persian_ci NOT NULL,
  `user_phone` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_persian_ci COMMENT='information table';

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_username`, `user_fullname`, `user_Email`, `user_password`, `user_phone`) VALUES
(1, 'fati1', 'fatemeh', 'gjfhsjfh@yahoo', '1234', 2588),
(2, 'userlj', 'user22', 'usertwenty@yahoo.com', '1234', 253698741),
(11, 'ghaf', 'فاطم غفوری', 'ghafourifa@yahoo.com', '1234', 25253654),
(10, 'jbjnkm', 'lm,.', 'kmjml', 'jnnklmm', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `reqorder`
--
ALTER TABLE `reqorder`
  ADD PRIMARY KEY (`o_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `p_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `reqorder`
--
ALTER TABLE `reqorder`
  MODIFY `o_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
