<html>
<head>
<link href="css/header-footer.css" rel="stylesheet">
</head>
<body>
<style>
.textresult{
	text-align: center;
	background-color: #BCBFF8;
}
</style>
<?php
session_start();
if(array_key_exists('username',$_POST) && array_key_exists('password',$_POST))
{
	$u=test_input($_POST['username']);
    $p=test_input($_POST['password']);
	
    include('db/connect.php');
    $query="SELECT `user_id`, `user_username`, `user_password` FROM `user` WHERE user_username='$u' AND user_password='$p' ";
    $result =$db->query($query);
	
    if($result->num_rows>0){
		$_SESSION['user']=$u;
		header('Homepage.html');?>
		<div dir=rtl class="textresult font11">
		کاربر <?php echo " ".$_POST["username"]; ?> ورود شما موفقیت آمیز بود
		<?php $username=$_POST['username'];
		$output= "Wellcome back to Aso Shop ".htmlspecialchars($username,ENT_QUOTES,"UTF-8")." !";?>
		<p dir="ltr" class="textresult"> <?php echo $output;?> </p>
		</div>
	<?php }
	else
	{?>
		<p dir="rtl" class="textresult font11" style="padding:5px"><?php echo " نام کاربری یا پسورد اشتباه است مجددا تلاش کنید ";?></p>
		<?php include 'login.html';
	}
	
	 include 'Homepage.html';
}
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
?><div>
</body>
<html>