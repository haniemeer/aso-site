<html>
<head>
<link href="css/header-footer.css" rel="stylesheet">
</head>
<body>
<style>
.text{
	text-align: center;
	background-color: #BCBFF8;
}
</style>
<?php
$username=$_POST['username'];
$password=$_POST['password'];
 if((isset($_POST ['username'])) && (isset($_POST['password']))){ ?>
<div dir=rtl class="text font11">
کاربر <?php echo " ".$_POST["username"]; ?> ورود شما موفقیت آمیز بود
<?php $username=$_POST['username'];
 $output= "Wellcome back to Aso Shop ".htmlspecialchars($username,ENT_QUOTES,"UTF-8")." !";?>
 <p dir="ltr" class="text"> <?php echo $output;?> </p>
</div>
<?php include 'Homepage.html'; ?>
<?php } ?>
<?php else{
	echo "You Must Fill Both Fields";
} ?>
</body>
<html>
